# Frontend‑Ordner

Dies ist der Platzhalter für das mobile Frontend von Life Quest Log.  Hier sollen später die UI‑Komponenten und Navigationsstrukturen implementiert werden, beispielsweise in React Native oder Flutter.  Aktuell enthält dieser Ordner noch keine Code‑Dateien.